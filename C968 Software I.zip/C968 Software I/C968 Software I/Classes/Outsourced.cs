﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C968_Software_I.Classes
{
    public class Outsourced:Part
    {
        public string CompanyName { get; set; }

    }
}
