﻿using C968_Software_I.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C968_Software_I.Forms
{
    public partial class ModifyProduct : Form
    {
        private BindingList<Part> partsToAssociate = new BindingList<Part>();
        public ModifyProduct(Product productToModify)
        {
            InitializeComponent();
            modifyProductAllParts.DataSource = Inventory.AllParts;
            partsToAssociate = productToModify.AssociatedParts;
            AssociatedPartsDGV.DataSource = partsToAssociate;

            modifyProductAllParts.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            modifyProductAllParts.ReadOnly = true;
            modifyProductAllParts.MultiSelect = false;
            modifyProductAllParts.AllowUserToAddRows = false;

            AssociatedPartsDGV.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            AssociatedPartsDGV.ReadOnly = true;
            AssociatedPartsDGV.MultiSelect = false;
            AssociatedPartsDGV.AllowUserToAddRows = false;

            ModifyProductID.Text = productToModify.ProductID.ToString();
            ModifyProductName.Text = productToModify.Name.ToString();
            ModifyProductInventory.Text = productToModify.InStock.ToString();
            ModifyProductPrice.Text = productToModify.Price.ToString();
            ModifyProductMax.Text = productToModify.Max.ToString();
            ModifyProductMin.Text = productToModify.Min.ToString();
        }

        //Event Listeners 
        private void ModifyProductInventory_KeyPress(object sender, KeyPressEventArgs e)
        {
            AddPart.NumericalsOnly(e);
        }

        private void ModifyPartPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            AddPart.IsDecimalValid(e);
        }

        private void ModifyPartMax_KeyPress(object sender, KeyPressEventArgs e)
        {
            AddPart.NumericalsOnly(e);
        }

        private void ModifyPartMin_KeyPress(object sender, KeyPressEventArgs e)
        {
            AddPart.NumericalsOnly(e);
        }

        private void deleteButton(object sender, EventArgs e)
        {
            Part partToDelete = (Part)AssociatedPartsDGV.CurrentRow.DataBoundItem;
            DialogResult answer = MessageBox.Show("Delete this associate part - are you sure?", "Confirm Delete", MessageBoxButtons.YesNo);

            if(answer == DialogResult.Yes)
            {
                try
                {
                    partsToAssociate.Remove(partToDelete);
                }
                catch (Exception err)
                { MessageBox.Show($"Error: {err.Message}"); }
                return;

            }

            return;
        }

        private void modifyProductSearchBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            AddPart.NumericalsOnly(e);
        }

        private void ModifyProductSaveButton_Click(object sender, EventArgs e)
        {
            try
            {
                Product productToModify = new Product
                {
                    ProductID = int.Parse(ModifyProductID.Text),
                    Name = ModifyProductName.Text,
                    InStock = int.Parse(ModifyProductInventory.Text),
                    Price = decimal.Parse(ModifyProductPrice.Text),
                    Max = int.Parse(ModifyProductMax.Text),
                    Min = int.Parse(ModifyProductMin.Text)

                };

                if(Inventory.ValidateMinMax(productToModify) == false)
                { return; }
                if (Inventory.ValidateInventory(productToModify) == false)
                { return; }


                foreach (DataGridViewRow row in AssociatedPartsDGV.Rows)
                {
                    Part associatedPart = (Part)row.DataBoundItem;
                    productToModify.AssociatedParts.Add(associatedPart);
                }

                Inventory.UpdateProduct(productToModify.ProductID, productToModify);
                this.Close();
            }


            catch (Exception err)
            {
                MessageBox.Show($"Please make sure all fields are complete. Message: {err.Message}");
                return;
            }
        }

       
        private void ModifyProductCancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void addAssociatedPartButton(object sender, EventArgs e)
        {
            
            Part partToAssociate = (Part)modifyProductAllParts.CurrentRow.DataBoundItem;
            partsToAssociate.Add(partToAssociate); 

        }

        private void modifyProductSearch_Click(object sender, EventArgs e)
        {
            try
            {
                int partIDToSearch = int.Parse(modifyProductSearchBox.Text);

                Part partToFind = Inventory.LookupPart(partIDToSearch);

                foreach (DataGridViewRow part in modifyProductAllParts.Rows)
                {
                    Part partToCheck = (Part)part.DataBoundItem;

                    if (partToCheck.PartID == partToFind.PartID)
                    {
                        part.Selected = true;
                        break;
                    }

                };
            }
            catch (Exception err)
            {
                { MessageBox.Show($"Error: {err.Message}"); }
            }
        }
    }
}
