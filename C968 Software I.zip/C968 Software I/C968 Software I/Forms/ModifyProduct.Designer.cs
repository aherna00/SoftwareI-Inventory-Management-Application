﻿
namespace C968_Software_I.Forms
{
    partial class ModifyProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.modifyProductSaveButton = new System.Windows.Forms.Button();
            this.ModifyProductCancelButton = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.ModifyProductMin = new System.Windows.Forms.TextBox();
            this.ModifyProductMax = new System.Windows.Forms.TextBox();
            this.ModifyProductPrice = new System.Windows.Forms.TextBox();
            this.ModifyProductName = new System.Windows.Forms.TextBox();
            this.ModifyProductInventory = new System.Windows.Forms.TextBox();
            this.ModifyProductID = new System.Windows.Forms.TextBox();
            this.AssociatedPartsDGV = new System.Windows.Forms.DataGridView();
            this.modifyProductAllParts = new System.Windows.Forms.DataGridView();
            this.modifyProductSearchBox = new System.Windows.Forms.TextBox();
            this.modifyProductSearch = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.AssociatedPartsDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.modifyProductAllParts)).BeginInit();
            this.SuspendLayout();
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(760, 469);
            this.label10.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(336, 25);
            this.label10.TabIndex = 58;
            this.label10.Text = "Parts associated with this Product";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(760, 129);
            this.label9.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(192, 25);
            this.label9.TabIndex = 57;
            this.label9.Text = "All candidate Parts";
            // 
            // modifyProductSaveButton
            // 
            this.modifyProductSaveButton.Location = new System.Drawing.Point(1170, 842);
            this.modifyProductSaveButton.Margin = new System.Windows.Forms.Padding(6);
            this.modifyProductSaveButton.Name = "modifyProductSaveButton";
            this.modifyProductSaveButton.Size = new System.Drawing.Size(150, 44);
            this.modifyProductSaveButton.TabIndex = 56;
            this.modifyProductSaveButton.Text = "Save";
            this.modifyProductSaveButton.UseVisualStyleBackColor = true;
            this.modifyProductSaveButton.Click += new System.EventHandler(this.ModifyProductSaveButton_Click);
            // 
            // ModifyProductCancelButton
            // 
            this.ModifyProductCancelButton.Location = new System.Drawing.Point(1332, 842);
            this.ModifyProductCancelButton.Margin = new System.Windows.Forms.Padding(6);
            this.ModifyProductCancelButton.Name = "ModifyProductCancelButton";
            this.ModifyProductCancelButton.Size = new System.Drawing.Size(150, 44);
            this.ModifyProductCancelButton.TabIndex = 55;
            this.ModifyProductCancelButton.Text = "Cancel";
            this.ModifyProductCancelButton.UseVisualStyleBackColor = true;
            this.ModifyProductCancelButton.Click += new System.EventHandler(this.ModifyProductCancelButton_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(1384, 787);
            this.button3.Margin = new System.Windows.Forms.Padding(6);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(96, 44);
            this.button3.TabIndex = 54;
            this.button3.Text = "Delete";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.deleteButton);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(1368, 450);
            this.button2.Margin = new System.Windows.Forms.Padding(6);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(114, 37);
            this.button2.TabIndex = 53;
            this.button2.Text = "Add";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.addAssociatedPartButton);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(412, 573);
            this.label7.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 25);
            this.label7.TabIndex = 52;
            this.label7.Text = "Min";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(158, 573);
            this.label6.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 25);
            this.label6.TabIndex = 51;
            this.label6.Text = "Max";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(198, 462);
            this.label5.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(111, 25);
            this.label5.TabIndex = 50;
            this.label5.Text = "Price/Cost";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(204, 387);
            this.label4.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 25);
            this.label4.TabIndex = 49;
            this.label4.Text = "Inventory";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(236, 317);
            this.label3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 25);
            this.label3.TabIndex = 48;
            this.label3.Text = "Name";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(236, 237);
            this.label8.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(32, 25);
            this.label8.TabIndex = 47;
            this.label8.Text = "ID";
            // 
            // ModifyProductMin
            // 
            this.ModifyProductMin.Location = new System.Drawing.Point(466, 567);
            this.ModifyProductMin.Margin = new System.Windows.Forms.Padding(6);
            this.ModifyProductMin.Name = "ModifyProductMin";
            this.ModifyProductMin.Size = new System.Drawing.Size(108, 31);
            this.ModifyProductMin.TabIndex = 46;
            this.ModifyProductMin.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ModifyPartMin_KeyPress);
            // 
            // ModifyProductMax
            // 
            this.ModifyProductMax.Location = new System.Drawing.Point(242, 567);
            this.ModifyProductMax.Margin = new System.Windows.Forms.Padding(6);
            this.ModifyProductMax.Name = "ModifyProductMax";
            this.ModifyProductMax.Size = new System.Drawing.Size(108, 31);
            this.ModifyProductMax.TabIndex = 45;
            this.ModifyProductMax.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ModifyPartMax_KeyPress);
            // 
            // ModifyProductPrice
            // 
            this.ModifyProductPrice.Location = new System.Drawing.Point(324, 456);
            this.ModifyProductPrice.Margin = new System.Windows.Forms.Padding(6);
            this.ModifyProductPrice.Name = "ModifyProductPrice";
            this.ModifyProductPrice.Size = new System.Drawing.Size(188, 31);
            this.ModifyProductPrice.TabIndex = 44;
            this.ModifyProductPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ModifyPartPrice_KeyPress);
            // 
            // ModifyProductName
            // 
            this.ModifyProductName.Location = new System.Drawing.Point(324, 312);
            this.ModifyProductName.Margin = new System.Windows.Forms.Padding(6);
            this.ModifyProductName.Name = "ModifyProductName";
            this.ModifyProductName.Size = new System.Drawing.Size(188, 31);
            this.ModifyProductName.TabIndex = 43;
            // 
            // ModifyProductInventory
            // 
            this.ModifyProductInventory.Location = new System.Drawing.Point(324, 381);
            this.ModifyProductInventory.Margin = new System.Windows.Forms.Padding(6);
            this.ModifyProductInventory.Name = "ModifyProductInventory";
            this.ModifyProductInventory.Size = new System.Drawing.Size(188, 31);
            this.ModifyProductInventory.TabIndex = 42;
            this.ModifyProductInventory.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ModifyProductInventory_KeyPress);
            // 
            // ModifyProductID
            // 
            this.ModifyProductID.Location = new System.Drawing.Point(324, 231);
            this.ModifyProductID.Margin = new System.Windows.Forms.Padding(6);
            this.ModifyProductID.Name = "ModifyProductID";
            this.ModifyProductID.ReadOnly = true;
            this.ModifyProductID.Size = new System.Drawing.Size(188, 31);
            this.ModifyProductID.TabIndex = 41;
            // 
            // AssociatedPartsDGV
            // 
            this.AssociatedPartsDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.AssociatedPartsDGV.Location = new System.Drawing.Point(766, 510);
            this.AssociatedPartsDGV.Margin = new System.Windows.Forms.Padding(6);
            this.AssociatedPartsDGV.Name = "AssociatedPartsDGV";
            this.AssociatedPartsDGV.RowHeadersWidth = 82;
            this.AssociatedPartsDGV.Size = new System.Drawing.Size(716, 262);
            this.AssociatedPartsDGV.TabIndex = 40;
            // 
            // modifyProductAllParts
            // 
            this.modifyProductAllParts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.modifyProductAllParts.Location = new System.Drawing.Point(766, 163);
            this.modifyProductAllParts.Margin = new System.Windows.Forms.Padding(6);
            this.modifyProductAllParts.Name = "modifyProductAllParts";
            this.modifyProductAllParts.RowHeadersWidth = 82;
            this.modifyProductAllParts.Size = new System.Drawing.Size(716, 262);
            this.modifyProductAllParts.TabIndex = 39;
            // 
            // modifyProductSearchBox
            // 
            this.modifyProductSearchBox.Location = new System.Drawing.Point(1276, 85);
            this.modifyProductSearchBox.Margin = new System.Windows.Forms.Padding(6);
            this.modifyProductSearchBox.Name = "modifyProductSearchBox";
            this.modifyProductSearchBox.Size = new System.Drawing.Size(202, 31);
            this.modifyProductSearchBox.TabIndex = 38;
            this.modifyProductSearchBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.modifyProductSearchBox_KeyPress);
            // 
            // modifyProductSearch
            // 
            this.modifyProductSearch.Location = new System.Drawing.Point(1112, 85);
            this.modifyProductSearch.Margin = new System.Windows.Forms.Padding(6);
            this.modifyProductSearch.Name = "modifyProductSearch";
            this.modifyProductSearch.Size = new System.Drawing.Size(130, 38);
            this.modifyProductSearch.TabIndex = 37;
            this.modifyProductSearch.Text = "Search";
            this.modifyProductSearch.UseVisualStyleBackColor = true;
            this.modifyProductSearch.Click += new System.EventHandler(this.modifyProductSearch_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(602, 129);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 25);
            this.label2.TabIndex = 36;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(118, 48);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(156, 25);
            this.label1.TabIndex = 35;
            this.label1.Text = "Modify Product";
            // 
            // ModifyProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1600, 935);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.modifyProductSaveButton);
            this.Controls.Add(this.ModifyProductCancelButton);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.ModifyProductMin);
            this.Controls.Add(this.ModifyProductMax);
            this.Controls.Add(this.ModifyProductPrice);
            this.Controls.Add(this.ModifyProductName);
            this.Controls.Add(this.ModifyProductInventory);
            this.Controls.Add(this.ModifyProductID);
            this.Controls.Add(this.AssociatedPartsDGV);
            this.Controls.Add(this.modifyProductAllParts);
            this.Controls.Add(this.modifyProductSearchBox);
            this.Controls.Add(this.modifyProductSearch);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "ModifyProduct";
            this.Text = "ModifyProduct";
            ((System.ComponentModel.ISupportInitialize)(this.AssociatedPartsDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.modifyProductAllParts)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button modifyProductSaveButton;
        private System.Windows.Forms.Button ModifyProductCancelButton;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox ModifyProductMin;
        private System.Windows.Forms.TextBox ModifyProductMax;
        private System.Windows.Forms.TextBox ModifyProductPrice;
        private System.Windows.Forms.TextBox ModifyProductName;
        private System.Windows.Forms.TextBox ModifyProductInventory;
        private System.Windows.Forms.TextBox ModifyProductID;
        private System.Windows.Forms.DataGridView AssociatedPartsDGV;
        private System.Windows.Forms.DataGridView modifyProductAllParts;
        private System.Windows.Forms.TextBox modifyProductSearchBox;
        private System.Windows.Forms.Button modifyProductSearch;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}