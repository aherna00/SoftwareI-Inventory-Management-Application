﻿using C968_Software_I.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C968_Software_I
{
    public partial class ModifyPart : Form
    {
        public ModifyPart(Inhouse part)
        {
            InitializeComponent();
            InHouseButton.Checked = true;
            ModifyPartID.Text = part.PartID.ToString();
            ModifyPartName.Text = part.Name;
            ModifyPartInventory.Text = part.InStock.ToString();
            ModifyPartPrice.Text = part.Price.ToString();
            ModifyPartMax.Text = part.Max.ToString();
            ModifyPartMin.Text = part.Min.ToString();
            MachineCompanyText.Text = part.MachineID.ToString();

        }

        public ModifyPart(Outsourced part)
        {
            InitializeComponent();
            OutsourcedButton.Checked = true;
            ModifyPartID.Text = part.PartID.ToString();
            ModifyPartName.Text = part.Name;
            ModifyPartInventory.Text = part.InStock.ToString();
            ModifyPartPrice.Text = part.Price.ToString();
            ModifyPartMax.Text = part.Max.ToString();
            ModifyPartMin.Text = part.Min.ToString();
            MachineCompanyText.Text = part.CompanyName.ToString();
        }

        //Event Listeners 

        private void ModifyPartInventory_KeyPress(object sender, KeyPressEventArgs e)
        {
            AddPart.NumericalsOnly(e);
        }

        private void ModifyPartPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            AddPart.IsDecimalValid(e);
        }

        private void ModifyPartMax_KeyPress(object sender, KeyPressEventArgs e)
        {
            AddPart.NumericalsOnly(e);
        }

        private void ModifyPartMin_KeyPress(object sender, KeyPressEventArgs e)
        {
            AddPart.NumericalsOnly(e);
        }

        private void MachineCompanyText_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (machineCompanyLabel.Text == "Machine ID")
            {
                AddPart.NumericalsOnly(e);
            };
        }

        //--------


        private void InHouseButton_CheckedChanged(object sender, EventArgs e)
        {
            machineCompanyLabel.Text = "Machine ID";
            MachineCompanyText.Text = "";

        }

        private void OutsourcedButton_CheckedChanged(object sender, EventArgs e)
        {
            machineCompanyLabel.Text = "Company Name";
            MachineCompanyText.Text = "";

        }

        private void ModifyPartCancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ModifyPartSaveButton_Click(object sender, EventArgs e)
        {
            if (InHouseButton.Checked)
            {
                
                try
                {
                   
                    Part partToModify = new Inhouse
                    {
                        PartID = int.Parse(ModifyPartID.Text),
                        Name = ModifyPartName.Text,
                        Price = decimal.Parse(ModifyPartPrice.Text),
                        InStock = int.Parse(ModifyPartInventory.Text),
                        Min = int.Parse(ModifyPartMin.Text),
                        Max = int.Parse(ModifyPartMax.Text),
                        MachineID = int.Parse(MachineCompanyText.Text)

                    };

                    if (Inventory.ValidateMinMax(partToModify) == false)
                    { return; };

                    if (Inventory.ValidateInventory(partToModify) == false)
                    { return; };

                    Inventory.updatePart(partToModify.PartID, partToModify);

                    this.Close();
                }
                catch (Exception err)
                {
                    MessageBox.Show($"Please make sure all fields are complete. Message: {err.Message}");
                    return;
                }
            }
            else if (OutsourcedButton.Checked)
            {
                
                try
                {
                  
                    Part partToModify = new Outsourced
                    {
                        PartID = int.Parse(ModifyPartID.Text),
                        Name = ModifyPartName.Text,
                        Price = decimal.Parse(ModifyPartPrice.Text),
                        InStock = int.Parse(ModifyPartInventory.Text),
                        Min = int.Parse(ModifyPartMin.Text),
                        Max = int.Parse(ModifyPartMax.Text),
                        CompanyName = MachineCompanyText.Text

                    };

                    if (Inventory.ValidateMinMax(partToModify) == false)
                    { return; };

                    if (Inventory.ValidateInventory(partToModify) == false)
                    { return; };

                    Inventory.updatePart(partToModify.PartID, partToModify);

                    this.Close();
                }
                catch (Exception err)
                {
                    MessageBox.Show($"Please make sure all fields are complete. Message: {err.Message}");
                    return;
                }
            }
        }
    }
}
