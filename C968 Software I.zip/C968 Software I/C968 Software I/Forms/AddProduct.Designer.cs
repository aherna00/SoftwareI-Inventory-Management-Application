﻿
namespace C968_Software_I.Forms
{
    partial class AddProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.addProductSearchBox = new System.Windows.Forms.TextBox();
            this.addProductAllParts = new System.Windows.Forms.DataGridView();
            this.addAssociatedParts = new System.Windows.Forms.DataGridView();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.ProductMinTextBox = new System.Windows.Forms.TextBox();
            this.ProductMaxTextBox = new System.Windows.Forms.TextBox();
            this.ProductPriceTextBox = new System.Windows.Forms.TextBox();
            this.AddProductName = new System.Windows.Forms.TextBox();
            this.ProductInvTextBox = new System.Windows.Forms.TextBox();
            this.productID = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.deletePartButton = new System.Windows.Forms.Button();
            this.AddProductCancelButton = new System.Windows.Forms.Button();
            this.saveProductButton = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.addProductAllParts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.addAssociatedParts)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(68, 50);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Add Product";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(552, 131);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 25);
            this.label2.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1062, 87);
            this.button1.Margin = new System.Windows.Forms.Padding(6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(130, 38);
            this.button1.TabIndex = 2;
            this.button1.Text = "Search";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.searchBttn_Click);
            // 
            // addProductSearchBox
            // 
            this.addProductSearchBox.Location = new System.Drawing.Point(1226, 87);
            this.addProductSearchBox.Margin = new System.Windows.Forms.Padding(6);
            this.addProductSearchBox.Name = "addProductSearchBox";
            this.addProductSearchBox.Size = new System.Drawing.Size(202, 31);
            this.addProductSearchBox.TabIndex = 3;
            this.addProductSearchBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.addProductSearchBox_KeyPress);
            // 
            // addProductAllParts
            // 
            this.addProductAllParts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.addProductAllParts.Location = new System.Drawing.Point(716, 165);
            this.addProductAllParts.Margin = new System.Windows.Forms.Padding(6);
            this.addProductAllParts.Name = "addProductAllParts";
            this.addProductAllParts.RowHeadersWidth = 82;
            this.addProductAllParts.Size = new System.Drawing.Size(716, 262);
            this.addProductAllParts.TabIndex = 4;
            // 
            // addAssociatedParts
            // 
            this.addAssociatedParts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.addAssociatedParts.Location = new System.Drawing.Point(716, 512);
            this.addAssociatedParts.Margin = new System.Windows.Forms.Padding(6);
            this.addAssociatedParts.Name = "addAssociatedParts";
            this.addAssociatedParts.RowHeadersWidth = 82;
            this.addAssociatedParts.Size = new System.Drawing.Size(716, 262);
            this.addAssociatedParts.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(362, 575);
            this.label7.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 25);
            this.label7.TabIndex = 28;
            this.label7.Text = "Min";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(108, 575);
            this.label6.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 25);
            this.label6.TabIndex = 27;
            this.label6.Text = "Max";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(148, 463);
            this.label5.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(111, 25);
            this.label5.TabIndex = 26;
            this.label5.Text = "Price/Cost";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(154, 388);
            this.label4.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 25);
            this.label4.TabIndex = 25;
            this.label4.Text = "Inventory";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(186, 319);
            this.label3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 25);
            this.label3.TabIndex = 24;
            this.label3.Text = "Name";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(186, 238);
            this.label8.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(32, 25);
            this.label8.TabIndex = 23;
            this.label8.Text = "ID";
            // 
            // ProductMinTextBox
            // 
            this.ProductMinTextBox.Location = new System.Drawing.Point(416, 569);
            this.ProductMinTextBox.Margin = new System.Windows.Forms.Padding(6);
            this.ProductMinTextBox.Name = "ProductMinTextBox";
            this.ProductMinTextBox.Size = new System.Drawing.Size(108, 31);
            this.ProductMinTextBox.TabIndex = 22;
            this.ProductMinTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ProductMinTextBox_KeyPress);
            // 
            // ProductMaxTextBox
            // 
            this.ProductMaxTextBox.Location = new System.Drawing.Point(192, 569);
            this.ProductMaxTextBox.Margin = new System.Windows.Forms.Padding(6);
            this.ProductMaxTextBox.Name = "ProductMaxTextBox";
            this.ProductMaxTextBox.Size = new System.Drawing.Size(108, 31);
            this.ProductMaxTextBox.TabIndex = 21;
            this.ProductMaxTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ProductMaxTextBox_KeyPress);
            // 
            // ProductPriceTextBox
            // 
            this.ProductPriceTextBox.Location = new System.Drawing.Point(274, 458);
            this.ProductPriceTextBox.Margin = new System.Windows.Forms.Padding(6);
            this.ProductPriceTextBox.Name = "ProductPriceTextBox";
            this.ProductPriceTextBox.Size = new System.Drawing.Size(188, 31);
            this.ProductPriceTextBox.TabIndex = 20;
            this.ProductPriceTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ProductPriceTextBox_KeyPress);
            // 
            // AddProductName
            // 
            this.AddProductName.Location = new System.Drawing.Point(274, 313);
            this.AddProductName.Margin = new System.Windows.Forms.Padding(6);
            this.AddProductName.Name = "AddProductName";
            this.AddProductName.Size = new System.Drawing.Size(188, 31);
            this.AddProductName.TabIndex = 19;
            // 
            // ProductInvTextBox
            // 
            this.ProductInvTextBox.Location = new System.Drawing.Point(274, 383);
            this.ProductInvTextBox.Margin = new System.Windows.Forms.Padding(6);
            this.ProductInvTextBox.Name = "ProductInvTextBox";
            this.ProductInvTextBox.Size = new System.Drawing.Size(188, 31);
            this.ProductInvTextBox.TabIndex = 18;
            this.ProductInvTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ProductInvTextBox_KeyPress);
            // 
            // productID
            // 
            this.productID.Location = new System.Drawing.Point(274, 233);
            this.productID.Margin = new System.Windows.Forms.Padding(6);
            this.productID.Name = "productID";
            this.productID.ReadOnly = true;
            this.productID.Size = new System.Drawing.Size(188, 31);
            this.productID.TabIndex = 17;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(1318, 452);
            this.button2.Margin = new System.Windows.Forms.Padding(6);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(114, 37);
            this.button2.TabIndex = 29;
            this.button2.Text = "Add";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.addAssociatedPart_click);
            // 
            // deletePartButton
            // 
            this.deletePartButton.Location = new System.Drawing.Point(1334, 788);
            this.deletePartButton.Margin = new System.Windows.Forms.Padding(6);
            this.deletePartButton.Name = "deletePartButton";
            this.deletePartButton.Size = new System.Drawing.Size(96, 44);
            this.deletePartButton.TabIndex = 30;
            this.deletePartButton.Text = "Delete";
            this.deletePartButton.UseVisualStyleBackColor = true;
            this.deletePartButton.Click += new System.EventHandler(this.deletePartButton_Click);
            // 
            // AddProductCancelButton
            // 
            this.AddProductCancelButton.Location = new System.Drawing.Point(1282, 844);
            this.AddProductCancelButton.Margin = new System.Windows.Forms.Padding(6);
            this.AddProductCancelButton.Name = "AddProductCancelButton";
            this.AddProductCancelButton.Size = new System.Drawing.Size(150, 44);
            this.AddProductCancelButton.TabIndex = 31;
            this.AddProductCancelButton.Text = "Cancel";
            this.AddProductCancelButton.UseVisualStyleBackColor = true;
            this.AddProductCancelButton.Click += new System.EventHandler(this.AddProductCancelButton_Click);
            // 
            // saveProductButton
            // 
            this.saveProductButton.Location = new System.Drawing.Point(1120, 844);
            this.saveProductButton.Margin = new System.Windows.Forms.Padding(6);
            this.saveProductButton.Name = "saveProductButton";
            this.saveProductButton.Size = new System.Drawing.Size(150, 44);
            this.saveProductButton.TabIndex = 32;
            this.saveProductButton.Text = "Save";
            this.saveProductButton.UseVisualStyleBackColor = true;
            this.saveProductButton.Click += new System.EventHandler(this.saveButton);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(710, 131);
            this.label9.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(192, 25);
            this.label9.TabIndex = 33;
            this.label9.Text = "All candidate Parts";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(710, 471);
            this.label10.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(336, 25);
            this.label10.TabIndex = 34;
            this.label10.Text = "Parts associated with this Product";
            // 
            // AddProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1600, 935);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.saveProductButton);
            this.Controls.Add(this.AddProductCancelButton);
            this.Controls.Add(this.deletePartButton);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.ProductMinTextBox);
            this.Controls.Add(this.ProductMaxTextBox);
            this.Controls.Add(this.ProductPriceTextBox);
            this.Controls.Add(this.AddProductName);
            this.Controls.Add(this.ProductInvTextBox);
            this.Controls.Add(this.productID);
            this.Controls.Add(this.addAssociatedParts);
            this.Controls.Add(this.addProductAllParts);
            this.Controls.Add(this.addProductSearchBox);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "AddProduct";
            this.Text = "AddProduct";
            ((System.ComponentModel.ISupportInitialize)(this.addProductAllParts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.addAssociatedParts)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox addProductSearchBox;
        private System.Windows.Forms.DataGridView addProductAllParts;
        private System.Windows.Forms.DataGridView addAssociatedParts;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox ProductMinTextBox;
        private System.Windows.Forms.TextBox ProductMaxTextBox;
        private System.Windows.Forms.TextBox ProductPriceTextBox;
        private System.Windows.Forms.TextBox AddProductName;
        private System.Windows.Forms.TextBox ProductInvTextBox;
        private System.Windows.Forms.TextBox productID;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button deletePartButton;
        private System.Windows.Forms.Button AddProductCancelButton;
        private System.Windows.Forms.Button saveProductButton;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
    }
}