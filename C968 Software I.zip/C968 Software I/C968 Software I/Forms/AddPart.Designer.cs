﻿
namespace C968_Software_I
{
    partial class AddPart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.OutsourcedButton = new System.Windows.Forms.RadioButton();
            this.InHouseButton = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.partID = new System.Windows.Forms.TextBox();
            this.partInventory = new System.Windows.Forms.TextBox();
            this.partName = new System.Windows.Forms.TextBox();
            this.partCost = new System.Windows.Forms.TextBox();
            this.partMax = new System.Windows.Forms.TextBox();
            this.machineCompany = new System.Windows.Forms.TextBox();
            this.partMin = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.machineCompanyLabel = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SavePartButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // OutsourcedButton
            // 
            this.OutsourcedButton.AutoSize = true;
            this.OutsourcedButton.Location = new System.Drawing.Point(406, 44);
            this.OutsourcedButton.Margin = new System.Windows.Forms.Padding(6);
            this.OutsourcedButton.Name = "OutsourcedButton";
            this.OutsourcedButton.Size = new System.Drawing.Size(154, 29);
            this.OutsourcedButton.TabIndex = 0;
            this.OutsourcedButton.TabStop = true;
            this.OutsourcedButton.Text = "Outsourced";
            this.OutsourcedButton.UseVisualStyleBackColor = true;
            this.OutsourcedButton.CheckedChanged += new System.EventHandler(this.OutsourcedButton_CheckedChanged);
            // 
            // InHouseButton
            // 
            this.InHouseButton.AutoSize = true;
            this.InHouseButton.Location = new System.Drawing.Point(230, 44);
            this.InHouseButton.Margin = new System.Windows.Forms.Padding(6);
            this.InHouseButton.Name = "InHouseButton";
            this.InHouseButton.Size = new System.Drawing.Size(129, 29);
            this.InHouseButton.TabIndex = 1;
            this.InHouseButton.TabStop = true;
            this.InHouseButton.Text = "In-House";
            this.InHouseButton.UseVisualStyleBackColor = true;
            this.InHouseButton.CheckedChanged += new System.EventHandler(this.InHouseButton_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label1.Location = new System.Drawing.Point(24, 44);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 31);
            this.label1.TabIndex = 2;
            this.label1.Text = "Add Part";
            // 
            // partID
            // 
            this.partID.Location = new System.Drawing.Point(312, 150);
            this.partID.Margin = new System.Windows.Forms.Padding(6);
            this.partID.Name = "partID";
            this.partID.ReadOnly = true;
            this.partID.Size = new System.Drawing.Size(188, 31);
            this.partID.TabIndex = 3;
            // 
            // partInventory
            // 
            this.partInventory.Location = new System.Drawing.Point(312, 300);
            this.partInventory.Margin = new System.Windows.Forms.Padding(6);
            this.partInventory.Name = "partInventory";
            this.partInventory.Size = new System.Drawing.Size(188, 31);
            this.partInventory.TabIndex = 4;
            this.partInventory.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.partInventory_KeyPress);
            // 
            // partName
            // 
            this.partName.Location = new System.Drawing.Point(312, 231);
            this.partName.Margin = new System.Windows.Forms.Padding(6);
            this.partName.Name = "partName";
            this.partName.Size = new System.Drawing.Size(188, 31);
            this.partName.TabIndex = 5;
            // 
            // partCost
            // 
            this.partCost.Location = new System.Drawing.Point(312, 375);
            this.partCost.Margin = new System.Windows.Forms.Padding(6);
            this.partCost.Name = "partCost";
            this.partCost.Size = new System.Drawing.Size(188, 31);
            this.partCost.TabIndex = 6;
            this.partCost.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.partCost_KeyPress);
            // 
            // partMax
            // 
            this.partMax.Location = new System.Drawing.Point(230, 487);
            this.partMax.Margin = new System.Windows.Forms.Padding(6);
            this.partMax.Name = "partMax";
            this.partMax.Size = new System.Drawing.Size(108, 31);
            this.partMax.TabIndex = 7;
            this.partMax.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.partMax_KeyPress);
            // 
            // machineCompany
            // 
            this.machineCompany.Location = new System.Drawing.Point(312, 585);
            this.machineCompany.Margin = new System.Windows.Forms.Padding(6);
            this.machineCompany.Name = "machineCompany";
            this.machineCompany.Size = new System.Drawing.Size(188, 31);
            this.machineCompany.TabIndex = 9;
            this.machineCompany.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.machineCompany_KeyPress);
            // 
            // partMin
            // 
            this.partMin.Location = new System.Drawing.Point(454, 487);
            this.partMin.Margin = new System.Windows.Forms.Padding(6);
            this.partMin.Name = "partMin";
            this.partMin.Size = new System.Drawing.Size(108, 31);
            this.partMin.TabIndex = 10;
            this.partMin.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.partMin_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(224, 156);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 25);
            this.label2.TabIndex = 11;
            this.label2.Text = "ID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(224, 237);
            this.label3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 25);
            this.label3.TabIndex = 12;
            this.label3.Text = "Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(192, 306);
            this.label4.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 25);
            this.label4.TabIndex = 13;
            this.label4.Text = "Inventory";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(186, 381);
            this.label5.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(111, 25);
            this.label5.TabIndex = 14;
            this.label5.Text = "Price/Cost";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(146, 492);
            this.label6.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 25);
            this.label6.TabIndex = 15;
            this.label6.Text = "Max";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(400, 492);
            this.label7.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 25);
            this.label7.TabIndex = 16;
            this.label7.Text = "Min";
            // 
            // machineCompanyLabel
            // 
            this.machineCompanyLabel.AutoSize = true;
            this.machineCompanyLabel.Location = new System.Drawing.Point(146, 590);
            this.machineCompanyLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.machineCompanyLabel.Name = "machineCompanyLabel";
            this.machineCompanyLabel.Size = new System.Drawing.Size(120, 25);
            this.machineCompanyLabel.TabIndex = 17;
            this.machineCompanyLabel.Text = "Machine ID";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(562, 642);
            this.button1.Margin = new System.Windows.Forms.Padding(6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(126, 48);
            this.button1.TabIndex = 18;
            this.button1.Text = "Cancel";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // SavePartButton
            // 
            this.SavePartButton.Location = new System.Drawing.Point(406, 642);
            this.SavePartButton.Margin = new System.Windows.Forms.Padding(6);
            this.SavePartButton.Name = "SavePartButton";
            this.SavePartButton.Size = new System.Drawing.Size(126, 48);
            this.SavePartButton.TabIndex = 19;
            this.SavePartButton.Text = "Save";
            this.SavePartButton.UseVisualStyleBackColor = true;
            this.SavePartButton.Click += new System.EventHandler(this.SavePartButton_Click);
            // 
            // AddPart
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(718, 735);
            this.Controls.Add(this.SavePartButton);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.machineCompanyLabel);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.partMin);
            this.Controls.Add(this.machineCompany);
            this.Controls.Add(this.partMax);
            this.Controls.Add(this.partCost);
            this.Controls.Add(this.partName);
            this.Controls.Add(this.partInventory);
            this.Controls.Add(this.partID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.InHouseButton);
            this.Controls.Add(this.OutsourcedButton);
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "AddPart";
            this.Text = "AddPart";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton OutsourcedButton;
        private System.Windows.Forms.RadioButton InHouseButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox partID;
        private System.Windows.Forms.TextBox partInventory;
        private System.Windows.Forms.TextBox partName;
        private System.Windows.Forms.TextBox partCost;
        private System.Windows.Forms.TextBox partMax;
        private System.Windows.Forms.TextBox machineCompany;
        private System.Windows.Forms.TextBox partMin;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label machineCompanyLabel;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button SavePartButton;
    }
}