﻿using C968_Software_I.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C968_Software_I
{
    public partial class MainScreen : Form
    {
        public MainScreen()
        {
            InitializeComponent();

            PartsDataGrid.DataSource = Inventory.AllParts;
            ProductsDataGrid.DataSource = Inventory.Products;

            ProductsDataGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            ProductsDataGrid.ReadOnly = true;
            ProductsDataGrid.MultiSelect = false;
            ProductsDataGrid.AllowUserToAddRows = false;

            PartsDataGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            PartsDataGrid.ReadOnly = true;
            PartsDataGrid.MultiSelect = false;
            PartsDataGrid.AllowUserToAddRows = false;

        }

        private void AddPartButton_Click(object sender, EventArgs e)
        {
            AddPart form = new AddPart(); 
            form.Show();
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ModifyPartButton_Click(object sender, EventArgs e)
        {
            if (PartsDataGrid.CurrentRow.DataBoundItem.GetType() == typeof(Inhouse))
            {
                Inhouse partToModify = (Inhouse)PartsDataGrid.CurrentRow.DataBoundItem;
                ModifyPart form = new ModifyPart(partToModify);
                form.Show();

            }
            else if(PartsDataGrid.CurrentRow.DataBoundItem.GetType() == typeof(Outsourced))
            {
                Outsourced partToModify = (Outsourced)PartsDataGrid.CurrentRow.DataBoundItem;
                ModifyPart form = new ModifyPart(partToModify);
                form.Show();
            }
        }

        private void DeletePartButton_Click(object sender, EventArgs e)
        {
            Part partToDelete = (Part)PartsDataGrid.CurrentRow.DataBoundItem;
            DialogResult answer = MessageBox.Show($"Delete this part {partToDelete.Name}  - are you sure?", "Confirm Delete", MessageBoxButtons.YesNo);
            if (answer == DialogResult.Yes) 
            {
                try
                {
                    Inventory.DeletePart(partToDelete);
                }
                catch (Exception err)
                {
                    MessageBox.Show($"Error: {err.Message}");
                }

                return;
            }

            return;

        }

        private void ModifyProductButton_Click(object sender, EventArgs e)
        {
            Product productToModify = (Product)ProductsDataGrid.CurrentRow.DataBoundItem;
            Forms.ModifyProduct form = new Forms.ModifyProduct(productToModify);
            form.Show();
        }

        private void DeleteProductButton_Click(object sender, EventArgs e)
        {
            Product productToDelete = (Product)ProductsDataGrid.CurrentRow.DataBoundItem;

            if (productToDelete.AssociatedParts.Count > 0)
            {
                MessageBox.Show($"Cannot delete Product with ID: {productToDelete.ProductID}. Please remove associated parts first");
                return;
            }

            DialogResult answer = MessageBox.Show($"Delete this product {productToDelete.Name} - are you sure?", "Confirm Delete", MessageBoxButtons.YesNo);
            if (answer == DialogResult.Yes)
            {
                try
                { Inventory.RemoveProduct(productToDelete.ProductID); }
                catch (Exception err)
                {
                    MessageBox.Show($"Error: {err.Message}");
                }
                return;
            }
            return;
        }

        private void AddProductButton_Click(object sender, EventArgs e)
        {
            Forms.AddProduct form = new Forms.AddProduct();
            form.Show();
        }

        private void PartSearchBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            AddPart.NumericalsOnly(e);
        }

        private void ProductSearchBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            AddPart.NumericalsOnly(e);
        }

        private void SearchPartButton_Click(object sender, EventArgs e)
        {
            try 
            {
                int partIDToSearch = int.Parse(PartSearchBox.Text);

                Part partToFind = Inventory.LookupPart(partIDToSearch);

                foreach (DataGridViewRow part in PartsDataGrid.Rows)
                {
                    Part partToCheck = (Part)part.DataBoundItem;

                    if (partToCheck.PartID == partToFind.PartID)
                    {
                        part.Selected = true;
                        break;
                    }

                };
            }
            catch (Exception err)
            {
                { MessageBox.Show($"Error: {err.Message}"); }
            }
        }

        private void SearchProductButton_Click(object sender, EventArgs e)
        {
            try 
            {
                int productIDToSearch = int.Parse(ProductSearchBox.Text);

                Product productToFind = Inventory.LookupProduct(productIDToSearch);

                foreach (DataGridViewRow product in ProductsDataGrid.Rows)
                {
                    Product productToCheck = (Product)product.DataBoundItem;

                    if (productToCheck.ProductID == productToFind.ProductID)
                    {
                        product.Selected = true;
                        break;
                    }

                }
            }
            catch (Exception err)
            { MessageBox.Show($"Error: {err.Message}"); }
            
        }
    }
}
