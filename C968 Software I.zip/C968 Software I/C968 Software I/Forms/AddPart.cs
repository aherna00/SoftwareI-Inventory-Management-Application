﻿using C968_Software_I.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C968_Software_I
{
    public partial class AddPart : Form
    {
        public AddPart()
        {
            InitializeComponent();
            partID.Text = Inventory.GenerateID().ToString();
           
        }

        //Validate Functions 

        public static void NumericalsOnly(KeyPressEventArgs key)
        {
            if (!char.IsDigit(key.KeyChar) && !char.IsControl(key.KeyChar))
            {
                key.Handled = true;
                MessageBox.Show("This field accepts whole numbers only");
                
            };
        }

        public static void IsDecimalValid(KeyPressEventArgs key)
        {
            if (!char.IsDigit(key.KeyChar) && !char.IsControl(key.KeyChar) && key.KeyChar != '.')
            {
                key.Handled = true;
                MessageBox.Show("This field accepts numbers only - please use xx.xx format");

            };
        }

        //--------

        //Event Listeners

        private void partMax_KeyPress(object sender, KeyPressEventArgs e)
        {
            NumericalsOnly(e);
        }

        private void partMin_KeyPress(object sender, KeyPressEventArgs e)
        {
            NumericalsOnly(e);
        }

        private void partCost_KeyPress(object sender, KeyPressEventArgs e)
        {
            IsDecimalValid(e);
        }

        private void partInventory_KeyPress(object sender, KeyPressEventArgs e)
        {
            NumericalsOnly(e);
        }

        private void machineCompany_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (machineCompanyLabel.Text == "Machine ID")
            {
                NumericalsOnly(e);
            };
        }

        //--------

       

        private void InHouseButton_CheckedChanged(object sender, EventArgs e)
        {
            machineCompanyLabel.Text = "Machine ID";
            machineCompany.Text = "";
        }

        private void OutsourcedButton_CheckedChanged(object sender, EventArgs e)
        {
            machineCompanyLabel.Text = "Company Name";
            machineCompany.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void SavePartButton_Click(object sender, EventArgs e)
        {

            if (InHouseButton.Checked)
            {
                try
                {
                    Part newPart = new Inhouse
                    {
                        PartID = int.Parse(partID.Text),
                        Name = partName.Text,
                        Price = decimal.Parse(partCost.Text),
                        InStock = int.Parse(partInventory.Text),
                        Min = int.Parse(partMin.Text),
                        Max = int.Parse(partMax.Text),
                        MachineID = int.Parse(machineCompany.Text)

                    };

                    if (Inventory.ValidateMinMax(newPart) == false)
                    { return; };

                    if (Inventory.ValidateInventory(newPart) == false)
                    { return; };

                    Inventory.AddPart(newPart);

                    this.Close();
                }
                catch(Exception err)
                {
                    MessageBox.Show($"Please make sure all fields are complete. Message: {err.Message}");
                    return;
                }
            }
            else if (OutsourcedButton.Checked)
            {
                try
                {
                    Part newPart = new Outsourced
                    {
                        PartID = int.Parse(partID.Text),
                        Name = partName.Text,
                        Price = decimal.Parse(partCost.Text),
                        InStock = int.Parse(partInventory.Text),
                        Min = int.Parse(partMin.Text),
                        Max = int.Parse(partMax.Text),
                        CompanyName = machineCompany.Text

                    };

                    if (Inventory.ValidateMinMax(newPart) == false)
                    { return; };

                    if (Inventory.ValidateInventory(newPart) == false)
                    { return; };

                    Inventory.AddPart(newPart);
                    this.Close();
                }
                catch(Exception err)
                {
                    MessageBox.Show($"Please make sure all fields are complete. Message: {err.Message}");
                    return;
                }
            }
        }
    }
}
