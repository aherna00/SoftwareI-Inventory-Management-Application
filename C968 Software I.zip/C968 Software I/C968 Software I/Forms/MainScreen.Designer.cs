﻿
namespace C968_Software_I
{
    partial class MainScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SearchPartButton = new System.Windows.Forms.Button();
            this.PartSearchBox = new System.Windows.Forms.TextBox();
            this.ProductSearchBox = new System.Windows.Forms.TextBox();
            this.SearchProductButton = new System.Windows.Forms.Button();
            this.AddPartButton = new System.Windows.Forms.Button();
            this.AddProductButton = new System.Windows.Forms.Button();
            this.ModifyProductButton = new System.Windows.Forms.Button();
            this.ModifyPartButton = new System.Windows.Forms.Button();
            this.DeleteProductButton = new System.Windows.Forms.Button();
            this.DeletePartButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.ProductLabel = new System.Windows.Forms.Label();
            this.PartLabel = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.PartsDataGrid = new System.Windows.Forms.DataGridView();
            this.ProductsDataGrid = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.PartsDataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ProductsDataGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // SearchPartButton
            // 
            this.SearchPartButton.Location = new System.Drawing.Point(490, 127);
            this.SearchPartButton.Margin = new System.Windows.Forms.Padding(4);
            this.SearchPartButton.Name = "SearchPartButton";
            this.SearchPartButton.Size = new System.Drawing.Size(100, 54);
            this.SearchPartButton.TabIndex = 7;
            this.SearchPartButton.Text = "Search";
            this.SearchPartButton.UseVisualStyleBackColor = true;
            this.SearchPartButton.Click += new System.EventHandler(this.SearchPartButton_Click);
            // 
            // PartSearchBox
            // 
            this.PartSearchBox.Location = new System.Drawing.Point(626, 137);
            this.PartSearchBox.Margin = new System.Windows.Forms.Padding(4);
            this.PartSearchBox.Name = "PartSearchBox";
            this.PartSearchBox.Size = new System.Drawing.Size(252, 31);
            this.PartSearchBox.TabIndex = 9;
            this.PartSearchBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.PartSearchBox_KeyPress);
            // 
            // ProductSearchBox
            // 
            this.ProductSearchBox.Location = new System.Drawing.Point(1486, 131);
            this.ProductSearchBox.Margin = new System.Windows.Forms.Padding(4);
            this.ProductSearchBox.Name = "ProductSearchBox";
            this.ProductSearchBox.Size = new System.Drawing.Size(252, 31);
            this.ProductSearchBox.TabIndex = 10;
            this.ProductSearchBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ProductSearchBox_KeyPress);
            // 
            // SearchProductButton
            // 
            this.SearchProductButton.Location = new System.Drawing.Point(1358, 121);
            this.SearchProductButton.Margin = new System.Windows.Forms.Padding(4);
            this.SearchProductButton.Name = "SearchProductButton";
            this.SearchProductButton.Size = new System.Drawing.Size(100, 54);
            this.SearchProductButton.TabIndex = 11;
            this.SearchProductButton.Text = "Search";
            this.SearchProductButton.UseVisualStyleBackColor = true;
            this.SearchProductButton.Click += new System.EventHandler(this.SearchProductButton_Click);
            // 
            // AddPartButton
            // 
            this.AddPartButton.Location = new System.Drawing.Point(490, 652);
            this.AddPartButton.Margin = new System.Windows.Forms.Padding(4);
            this.AddPartButton.Name = "AddPartButton";
            this.AddPartButton.Size = new System.Drawing.Size(100, 54);
            this.AddPartButton.TabIndex = 12;
            this.AddPartButton.Text = "Add";
            this.AddPartButton.UseVisualStyleBackColor = true;
            this.AddPartButton.Click += new System.EventHandler(this.AddPartButton_Click);
            // 
            // AddProductButton
            // 
            this.AddProductButton.Location = new System.Drawing.Point(1396, 652);
            this.AddProductButton.Margin = new System.Windows.Forms.Padding(4);
            this.AddProductButton.Name = "AddProductButton";
            this.AddProductButton.Size = new System.Drawing.Size(100, 54);
            this.AddProductButton.TabIndex = 13;
            this.AddProductButton.Text = "Add";
            this.AddProductButton.UseVisualStyleBackColor = true;
            this.AddProductButton.Click += new System.EventHandler(this.AddProductButton_Click);
            // 
            // ModifyProductButton
            // 
            this.ModifyProductButton.Location = new System.Drawing.Point(1530, 652);
            this.ModifyProductButton.Margin = new System.Windows.Forms.Padding(4);
            this.ModifyProductButton.Name = "ModifyProductButton";
            this.ModifyProductButton.Size = new System.Drawing.Size(100, 54);
            this.ModifyProductButton.TabIndex = 14;
            this.ModifyProductButton.Text = "Modify";
            this.ModifyProductButton.UseVisualStyleBackColor = true;
            this.ModifyProductButton.Click += new System.EventHandler(this.ModifyProductButton_Click);
            // 
            // ModifyPartButton
            // 
            this.ModifyPartButton.Location = new System.Drawing.Point(626, 652);
            this.ModifyPartButton.Margin = new System.Windows.Forms.Padding(4);
            this.ModifyPartButton.Name = "ModifyPartButton";
            this.ModifyPartButton.Size = new System.Drawing.Size(100, 54);
            this.ModifyPartButton.TabIndex = 15;
            this.ModifyPartButton.Text = "Modify";
            this.ModifyPartButton.UseVisualStyleBackColor = true;
            this.ModifyPartButton.Click += new System.EventHandler(this.ModifyPartButton_Click);
            // 
            // DeleteProductButton
            // 
            this.DeleteProductButton.Location = new System.Drawing.Point(1660, 652);
            this.DeleteProductButton.Margin = new System.Windows.Forms.Padding(4);
            this.DeleteProductButton.Name = "DeleteProductButton";
            this.DeleteProductButton.Size = new System.Drawing.Size(100, 54);
            this.DeleteProductButton.TabIndex = 16;
            this.DeleteProductButton.Text = "Delete";
            this.DeleteProductButton.UseVisualStyleBackColor = true;
            this.DeleteProductButton.Click += new System.EventHandler(this.DeleteProductButton_Click);
            // 
            // DeletePartButton
            // 
            this.DeletePartButton.Location = new System.Drawing.Point(758, 652);
            this.DeletePartButton.Margin = new System.Windows.Forms.Padding(4);
            this.DeletePartButton.Name = "DeletePartButton";
            this.DeletePartButton.Size = new System.Drawing.Size(100, 54);
            this.DeletePartButton.TabIndex = 17;
            this.DeletePartButton.Text = "Delete";
            this.DeletePartButton.UseVisualStyleBackColor = true;
            this.DeletePartButton.Click += new System.EventHandler(this.DeletePartButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(1660, 781);
            this.ExitButton.Margin = new System.Windows.Forms.Padding(4);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(100, 54);
            this.ExitButton.TabIndex = 18;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // ProductLabel
            // 
            this.ProductLabel.AutoSize = true;
            this.ProductLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.ProductLabel.Location = new System.Drawing.Point(976, 152);
            this.ProductLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ProductLabel.Name = "ProductLabel";
            this.ProductLabel.Size = new System.Drawing.Size(122, 31);
            this.ProductLabel.TabIndex = 21;
            this.ProductLabel.Text = "Products";
            // 
            // PartLabel
            // 
            this.PartLabel.AutoSize = true;
            this.PartLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.PartLabel.Location = new System.Drawing.Point(108, 152);
            this.PartLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.PartLabel.Name = "PartLabel";
            this.PartLabel.Size = new System.Drawing.Size(78, 31);
            this.PartLabel.TabIndex = 22;
            this.PartLabel.Text = "Parts";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label3.Location = new System.Drawing.Point(12, 10);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(455, 37);
            this.label3.TabIndex = 23;
            this.label3.Text = "Inventory Management System";
            // 
            // PartsDataGrid
            // 
            this.PartsDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.PartsDataGrid.Location = new System.Drawing.Point(112, 196);
            this.PartsDataGrid.Margin = new System.Windows.Forms.Padding(4);
            this.PartsDataGrid.Name = "PartsDataGrid";
            this.PartsDataGrid.RowHeadersWidth = 82;
            this.PartsDataGrid.RowTemplate.Height = 33;
            this.PartsDataGrid.Size = new System.Drawing.Size(770, 435);
            this.PartsDataGrid.TabIndex = 24;
            // 
            // ProductsDataGrid
            // 
            this.ProductsDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ProductsDataGrid.Location = new System.Drawing.Point(972, 196);
            this.ProductsDataGrid.Margin = new System.Windows.Forms.Padding(4);
            this.ProductsDataGrid.Name = "ProductsDataGrid";
            this.ProductsDataGrid.RowHeadersWidth = 82;
            this.ProductsDataGrid.RowTemplate.Height = 33;
            this.ProductsDataGrid.Size = new System.Drawing.Size(770, 435);
            this.ProductsDataGrid.TabIndex = 25;
            // 
            // MainScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1770, 888);
            this.Controls.Add(this.ProductsDataGrid);
            this.Controls.Add(this.PartsDataGrid);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.PartLabel);
            this.Controls.Add(this.ProductLabel);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.DeletePartButton);
            this.Controls.Add(this.DeleteProductButton);
            this.Controls.Add(this.ModifyPartButton);
            this.Controls.Add(this.ModifyProductButton);
            this.Controls.Add(this.AddProductButton);
            this.Controls.Add(this.AddPartButton);
            this.Controls.Add(this.SearchProductButton);
            this.Controls.Add(this.ProductSearchBox);
            this.Controls.Add(this.PartSearchBox);
            this.Controls.Add(this.SearchPartButton);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MainScreen";
            this.Text = "Main Screen";
            ((System.ComponentModel.ISupportInitialize)(this.PartsDataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ProductsDataGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button SearchPartButton;
        private System.Windows.Forms.TextBox PartSearchBox;
        private System.Windows.Forms.TextBox ProductSearchBox;
        private System.Windows.Forms.Button SearchProductButton;
        private System.Windows.Forms.Button AddPartButton;
        private System.Windows.Forms.Button AddProductButton;
        private System.Windows.Forms.Button ModifyProductButton;
        private System.Windows.Forms.Button ModifyPartButton;
        private System.Windows.Forms.Button DeleteProductButton;
        private System.Windows.Forms.Button DeletePartButton;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.Label ProductLabel;
        private System.Windows.Forms.Label PartLabel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView PartsDataGrid;
        private System.Windows.Forms.DataGridView ProductsDataGrid;
    }
}

