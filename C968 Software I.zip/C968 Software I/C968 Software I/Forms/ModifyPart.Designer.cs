﻿
namespace C968_Software_I
{
    partial class ModifyPart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.machineCompanyLabel = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ModifyPartMin = new System.Windows.Forms.TextBox();
            this.MachineCompanyText = new System.Windows.Forms.TextBox();
            this.ModifyPartMax = new System.Windows.Forms.TextBox();
            this.ModifyPartPrice = new System.Windows.Forms.TextBox();
            this.ModifyPartName = new System.Windows.Forms.TextBox();
            this.ModifyPartInventory = new System.Windows.Forms.TextBox();
            this.ModifyPartID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.InHouseButton = new System.Windows.Forms.RadioButton();
            this.OutsourcedButton = new System.Windows.Forms.RadioButton();
            this.ModifyPartCancelButton = new System.Windows.Forms.Button();
            this.ModifyPartSaveButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // machineCompanyLabel
            // 
            this.machineCompanyLabel.AutoSize = true;
            this.machineCompanyLabel.Location = new System.Drawing.Point(146, 594);
            this.machineCompanyLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.machineCompanyLabel.Name = "machineCompanyLabel";
            this.machineCompanyLabel.Size = new System.Drawing.Size(120, 25);
            this.machineCompanyLabel.TabIndex = 34;
            this.machineCompanyLabel.Text = "Machine ID";

            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(400, 496);
            this.label7.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 25);
            this.label7.TabIndex = 33;
            this.label7.Text = "Min";

            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(146, 496);
            this.label6.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 25);
            this.label6.TabIndex = 32;
            this.label6.Text = "Max";

            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(186, 385);
            this.label5.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(111, 25);
            this.label5.TabIndex = 31;
            this.label5.Text = "Price/Cost";

            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(192, 310);
            this.label4.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 25);
            this.label4.TabIndex = 30;
            this.label4.Text = "Inventory";

            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(224, 240);
            this.label3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 25);
            this.label3.TabIndex = 29;
            this.label3.Text = "Name";

            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(224, 160);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 25);
            this.label2.TabIndex = 28;
            this.label2.Text = "ID";

            // 
            // ModifyPartMin
            // 
            this.ModifyPartMin.Location = new System.Drawing.Point(454, 490);
            this.ModifyPartMin.Margin = new System.Windows.Forms.Padding(6);
            this.ModifyPartMin.Name = "ModifyPartMin";
            this.ModifyPartMin.Size = new System.Drawing.Size(108, 31);
            this.ModifyPartMin.TabIndex = 27;

            this.ModifyPartMin.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ModifyPartMin_KeyPress);
            // 
            // MachineCompanyText
            // 
            this.MachineCompanyText.Location = new System.Drawing.Point(312, 588);
            this.MachineCompanyText.Margin = new System.Windows.Forms.Padding(6);
            this.MachineCompanyText.Name = "MachineCompanyText";
            this.MachineCompanyText.Size = new System.Drawing.Size(188, 31);
            this.MachineCompanyText.TabIndex = 26;
            this.MachineCompanyText.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MachineCompanyText_KeyPress);
            // 
            // ModifyPartMax
            // 
            this.ModifyPartMax.Location = new System.Drawing.Point(230, 490);
            this.ModifyPartMax.Margin = new System.Windows.Forms.Padding(6);
            this.ModifyPartMax.Name = "ModifyPartMax";
            this.ModifyPartMax.Size = new System.Drawing.Size(108, 31);
            this.ModifyPartMax.TabIndex = 25;
            this.ModifyPartMax.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ModifyPartMax_KeyPress);
            // 
            // ModifyPartPrice
            // 
            this.ModifyPartPrice.Location = new System.Drawing.Point(312, 379);
            this.ModifyPartPrice.Margin = new System.Windows.Forms.Padding(6);
            this.ModifyPartPrice.Name = "ModifyPartPrice";
            this.ModifyPartPrice.Size = new System.Drawing.Size(188, 31);
            this.ModifyPartPrice.TabIndex = 24;
            this.ModifyPartPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ModifyPartPrice_KeyPress);
            // 
            // ModifyPartName
            // 
            this.ModifyPartName.Location = new System.Drawing.Point(312, 235);
            this.ModifyPartName.Margin = new System.Windows.Forms.Padding(6);
            this.ModifyPartName.Name = "ModifyPartName";
            this.ModifyPartName.Size = new System.Drawing.Size(188, 31);
            this.ModifyPartName.TabIndex = 23;
            // 
            // ModifyPartInventory
            // 
            this.ModifyPartInventory.Location = new System.Drawing.Point(312, 304);
            this.ModifyPartInventory.Margin = new System.Windows.Forms.Padding(6);
            this.ModifyPartInventory.Name = "ModifyPartInventory";
            this.ModifyPartInventory.Size = new System.Drawing.Size(188, 31);
            this.ModifyPartInventory.TabIndex = 22;
            this.ModifyPartInventory.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ModifyPartInventory_KeyPress);
            // 
            // ModifyPartID
            // 
            this.ModifyPartID.Location = new System.Drawing.Point(312, 154);
            this.ModifyPartID.Margin = new System.Windows.Forms.Padding(6);
            this.ModifyPartID.Name = "ModifyPartID";
            this.ModifyPartID.ReadOnly = true;
            this.ModifyPartID.Size = new System.Drawing.Size(188, 31);
            this.ModifyPartID.TabIndex = 21;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label1.Location = new System.Drawing.Point(24, 48);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(151, 31);
            this.label1.TabIndex = 20;
            this.label1.Text = "Modify Part";
            // 
            // InHouseButton
            // 
            this.InHouseButton.AutoSize = true;
            this.InHouseButton.Location = new System.Drawing.Point(230, 48);
            this.InHouseButton.Margin = new System.Windows.Forms.Padding(6);
            this.InHouseButton.Name = "InHouseButton";
            this.InHouseButton.Size = new System.Drawing.Size(129, 29);
            this.InHouseButton.TabIndex = 19;
            this.InHouseButton.TabStop = true;
            this.InHouseButton.Text = "In-House";
            this.InHouseButton.UseVisualStyleBackColor = true;
            this.InHouseButton.CheckedChanged += new System.EventHandler(this.InHouseButton_CheckedChanged);
            // 
            // OutsourcedButton
            // 
            this.OutsourcedButton.AutoSize = true;
            this.OutsourcedButton.Location = new System.Drawing.Point(406, 48);
            this.OutsourcedButton.Margin = new System.Windows.Forms.Padding(6);
            this.OutsourcedButton.Name = "OutsourcedButton";
            this.OutsourcedButton.Size = new System.Drawing.Size(154, 29);
            this.OutsourcedButton.TabIndex = 18;
            this.OutsourcedButton.TabStop = true;
            this.OutsourcedButton.Text = "Outsourced";
            this.OutsourcedButton.UseVisualStyleBackColor = true;
            this.OutsourcedButton.CheckedChanged += new System.EventHandler(this.OutsourcedButton_CheckedChanged);
            // 
            // ModifyPartCancelButton
            // 
            this.ModifyPartCancelButton.Location = new System.Drawing.Point(578, 663);
            this.ModifyPartCancelButton.Margin = new System.Windows.Forms.Padding(6);
            this.ModifyPartCancelButton.Name = "ModifyPartCancelButton";
            this.ModifyPartCancelButton.Size = new System.Drawing.Size(132, 48);
            this.ModifyPartCancelButton.TabIndex = 35;
            this.ModifyPartCancelButton.Text = "Cancel";
            this.ModifyPartCancelButton.UseVisualStyleBackColor = true;
            this.ModifyPartCancelButton.Click += new System.EventHandler(this.ModifyPartCancelButton_Click);
            // 
            // ModifyPartSaveButton
            // 
            this.ModifyPartSaveButton.Location = new System.Drawing.Point(406, 663);
            this.ModifyPartSaveButton.Margin = new System.Windows.Forms.Padding(6);
            this.ModifyPartSaveButton.Name = "ModifyPartSaveButton";
            this.ModifyPartSaveButton.Size = new System.Drawing.Size(150, 44);
            this.ModifyPartSaveButton.TabIndex = 36;
            this.ModifyPartSaveButton.Text = "Save";
            this.ModifyPartSaveButton.UseVisualStyleBackColor = true;
            this.ModifyPartSaveButton.Click += new System.EventHandler(this.ModifyPartSaveButton_Click);
            // 
            // ModifyPart
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(718, 735);
            this.Controls.Add(this.ModifyPartSaveButton);
            this.Controls.Add(this.ModifyPartCancelButton);
            this.Controls.Add(this.machineCompanyLabel);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.ModifyPartMin);
            this.Controls.Add(this.MachineCompanyText);
            this.Controls.Add(this.ModifyPartMax);
            this.Controls.Add(this.ModifyPartPrice);
            this.Controls.Add(this.ModifyPartName);
            this.Controls.Add(this.ModifyPartInventory);
            this.Controls.Add(this.ModifyPartID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.InHouseButton);
            this.Controls.Add(this.OutsourcedButton);
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "ModifyPart";
            this.Text = "ModifyPart";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label machineCompanyLabel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox ModifyPartMin;
        private System.Windows.Forms.TextBox MachineCompanyText;
        private System.Windows.Forms.TextBox ModifyPartMax;
        private System.Windows.Forms.TextBox ModifyPartPrice;
        private System.Windows.Forms.TextBox ModifyPartName;
        private System.Windows.Forms.TextBox ModifyPartInventory;
        private System.Windows.Forms.TextBox ModifyPartID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton InHouseButton;
        private System.Windows.Forms.RadioButton OutsourcedButton;
        private System.Windows.Forms.Button ModifyPartCancelButton;
        private System.Windows.Forms.Button ModifyPartSaveButton;
    }
}