﻿using C968_Software_I.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C968_Software_I.Forms
{
    public partial class AddProduct : Form
    {
        private BindingList<Part> partsToAssociate = new BindingList<Part>();
        public AddProduct()
        {
            InitializeComponent();
            productID.Text = Inventory.GenerateID().ToString();
            addProductAllParts.DataSource = Inventory.AllParts;
            addAssociatedParts.DataSource = partsToAssociate;

            addProductAllParts.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            addProductAllParts.ReadOnly = true;
            addProductAllParts.MultiSelect = false;
            addProductAllParts.AllowUserToAddRows = false;

            addAssociatedParts.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            addAssociatedParts.ReadOnly = true;
            addAssociatedParts.MultiSelect = false;
            addAssociatedParts.AllowUserToAddRows = false;

        }


        //Event Listeners
        private void ProductMaxTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            AddPart.NumericalsOnly(e);
        }

        private void ProductMinTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            AddPart.NumericalsOnly(e);
        }
        private void ProductPriceTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            AddPart.IsDecimalValid(e);
        }

        private void ProductInvTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            AddPart.NumericalsOnly(e);
        }

        //--------

 

        private void AddProductCancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void saveButton(object sender, EventArgs e)
        {
            try {
                Product newProduct = new Product
                {
                    ProductID = int.Parse(productID.Text),
                    Name = AddProductName.Text,
                    InStock = int.Parse(ProductInvTextBox.Text),
                    Price = decimal.Parse(ProductPriceTextBox.Text),
                    Max = int.Parse(ProductMaxTextBox.Text),
                    Min = int.Parse(ProductMinTextBox.Text)


                };



                if (Inventory.ValidateMinMax(newProduct) == false)
                { return; }
                if (Inventory.ValidateInventory(newProduct) == false)
                { return; }

                foreach (DataGridViewRow row in addAssociatedParts.Rows)
                {
                    Part associatedPart = (Part)row.DataBoundItem;
                    newProduct.AssociatedParts.Add(associatedPart);
                }
                Inventory.AddProduct(newProduct);
                this.Close();
            }


            catch (Exception err)
            {
                MessageBox.Show($"Please make sure all fields are complete. Message: {err.Message}");
                return;
            }
        }

        private void addAssociatedPart_click(object sender, EventArgs e)
        {
            Part partToAssociate = (Part)addProductAllParts.CurrentRow.DataBoundItem;
            partsToAssociate.Add(partToAssociate);
        }

        private void deletePartButton_Click(object sender, EventArgs e)
        {
            Part partToDelete = (Part)addAssociatedParts.CurrentRow.DataBoundItem;
            DialogResult answer = MessageBox.Show("Delete this associate part - are you sure?", "Confirm Delete", MessageBoxButtons.YesNo);

            if (answer == DialogResult.Yes)
            {
                try
                {
                    partsToAssociate.Remove(partToDelete);
                }
                catch (Exception err)
                { MessageBox.Show($"Error: {err.Message}"); }
                return;

            }

            return;
        }

        private void searchBttn_Click(object sender, EventArgs e)
        {
            try
            {
                int partIDToSearch = int.Parse(addProductSearchBox.Text);

                Part partToFind = Inventory.LookupPart(partIDToSearch);

                foreach (DataGridViewRow part in addProductAllParts.Rows)
                {
                    Part partToCheck = (Part)part.DataBoundItem;

                    if (partToCheck.PartID == partToFind.PartID)
                    {
                        part.Selected = true;
                        break;
                    }

                };
            }
            catch (Exception err)
            {
                { MessageBox.Show($"Error: {err.Message}"); }
            }
        }

        private void addProductSearchBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            AddPart.NumericalsOnly(e);
        }
    }
}
